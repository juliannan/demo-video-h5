<template>
  <view class="index">
    <text>{{ msg }}</text>
    <video
      id="videoInfo"
      :src="videoData.src"
      :poster="videoData.poster"
      :show-mute-btn="videoData.showMuteBtn"
      :enable-play-gesture="videoData.enablePlayGesture"
      :show-center-play-btn="videoData.showCenterPlayBtn"
      :object-fit="videoData.objectFit"
      style="height: 500px;position: absolute"
    />
    <view class="text">
      <view style="color:red;position: absolute;top: 500px;">布局布局布局</view>
    </view>
  </view>
</template>

<script>
import './index.scss'

export default {
  data () {
    return {
      msg: 'Hello world!',
      videoData:{
        src:"http://community-data.s3-cache-accelerate.cn-north-1.jdcloud-oss.com/db90676c/476256486373654528/bb8ad96acdf44319b5682b5c21b5c74c-trans.mp4",
        poster:"",
        objectFit:'cover',
        showMuteBtn:true, // 静音按钮
        enablePlayGesture:true, //是否开启播放手势，即双击切换播放/暂停
        showCenterPlayBtn:false, //是否显示视频中间的播放按钮
      },
    }
  }
}
</script>
